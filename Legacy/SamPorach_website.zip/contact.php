<!DOCTYPE html>
<html>

<?php
	$page = 'contact';
	include("header.php");
?>	
	<h3>Send me a message!</h3>

	<body>
		Gonna be honest. This form is a placeholder. If you hit submit, it'll get mad at you.<br/>
		Once database functionality is in place, this'll submit to the database!<br/><br/>
		<form id = "contactform" action = "process.php" method="POST">
			Name:&emsp;<input placeholder = "Name" type = "text" name = "name" size="30" /><br/><br/>
			Email:&emsp;<input placeholder = "Email" type = "text" name = "email" size="30" /><br/><br/>
			Message:
			<br/><br/>
			<textarea form = "contactform" placeholder = "Write your message here" name = "message" cols = "35" rows = "5" wrap = "soft"></textarea>
			<br/><br/>
			<input type = "submit" value = "Submit" />
		</form>	
	</body>
	
</html>