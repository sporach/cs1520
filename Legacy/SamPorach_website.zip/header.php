<!DOCTYPE html>
<html>
<head>
   <title>Sam Porach's Homepage</title>
   <link rel="stylesheet" type="text/css" href="css/main.css">
</head>	

<header>
<?php
	include("pageheader.php");
?>	
</header>
<?php
	include("menu.php");
?>	
</html>